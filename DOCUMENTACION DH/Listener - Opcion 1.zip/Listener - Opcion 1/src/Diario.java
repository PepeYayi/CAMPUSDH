public class Diario extends Notificador{

    private String nombreDiario;

    @Override
    public void notificar() {
        for (Notificable unNotificable: notificables) {
            unNotificable.notificar(this);
        }
    }

    public String getNombreDiario() {
        return nombreDiario;
    }
}
