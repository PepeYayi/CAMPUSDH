package com.company;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Main {

    public static void main(String[] args) {

        Map<Integer, String> primerDiccionario = new HashMap<>();

        primerDiccionario.put(10, "Andres");

        primerDiccionario.put(11, "Lopi");

        primerDiccionario.put(12, "Nico");

        if(!primerDiccionario.containsKey(11)){
            primerDiccionario.put(11, "Jose");
        }
        System.out.println(primerDiccionario);

        Set<Integer> conjuntoDeClaves = primerDiccionario.keySet();
        System.out.println(conjuntoDeClaves);

        for(Integer unaClave : conjuntoDeClaves){
            System.out.println(unaClave + ": " + primerDiccionario.get(unaClave));
        }
    }
}
