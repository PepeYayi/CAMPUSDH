package com.example.viewpager;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ma on 23/04/18.
 */

public class AdapterViewPager extends FragmentStatePagerAdapter {

    private List<Fragment> listaFragments;

    public AdapterViewPager(FragmentManager fm, List<Integer> listaColores) {
        super(fm);
        listaFragments = new ArrayList<>();
        for (Integer color : listaColores) {
            FragmentColor fragmentColor = FragmentColor.fabricaFragmentsColor(color);
            listaFragments.add(fragmentColor);
        }
    }

    @Override
    public Fragment getItem(int position) {
        return listaFragments.get(position);
    }

    @Override
    public int getCount() {
        return listaFragments.size();
    }
}
