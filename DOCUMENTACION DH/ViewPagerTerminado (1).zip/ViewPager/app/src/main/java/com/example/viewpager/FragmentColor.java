package com.example.viewpager;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentColor extends Fragment {


    public static final String ID_COLOR = "idColor";


    public static FragmentColor fabricaFragmentsColor(Integer idColor){

        FragmentColor fragmentColor = new FragmentColor();
        Bundle bundle = new Bundle();
        bundle.putInt(ID_COLOR, idColor);
        fragmentColor.setArguments(bundle);
        return fragmentColor;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_blank, container, false);

        FrameLayout layout = view.findViewById(R.id.LayoutFondo);

        layout.setBackgroundColor(getArguments().getInt(ID_COLOR));


        return view;
    }

}
