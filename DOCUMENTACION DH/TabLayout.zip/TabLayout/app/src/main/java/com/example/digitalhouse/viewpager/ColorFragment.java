package com.example.digitalhouse.viewpager;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class ColorFragment extends Fragment {


    private static final java.lang.String COLOR = "Fondo";

    private Integer color;

    //ESTE METODO ME PERMITE CREAR FRAGMENTS INFORMANDOLE EL COLOR QUE QUIERO.
    //ES UNA FUNCION QUE ME PERMITE FABRICAR FRAGMENTS (Patron Factory).
    //SE UTILIZA UN BUNDLE EN DONDE GUARDO TODOS LOS ATRIBUTOS QUE QUIERA UTILIZAR PARA MI FRAGMENT
    public static ColorFragment fragmentColorCreator(Integer color) {

        ColorFragment colorFragment = new ColorFragment();
        Bundle unBundle = new Bundle();
        unBundle.putInt(COLOR, color);
        colorFragment.setArguments(unBundle);
        return colorFragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_color, container, false);

        //RECUPERO EL BUNDLE Y UTILIZO LA INFORMACIÓN QUE LE CARGUE
        Bundle unBundle = getArguments();

        Integer color = unBundle.getInt(COLOR);

        view.setBackgroundColor(color);

        return view;
    }
}
