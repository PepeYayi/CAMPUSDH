package com.example.digitalhouse.viewpager;

import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //BUSCO EL VIEW PAGER
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewPager);

        //CREO UNA LISTA DE COLORES PARA QUE SE CREEN VARIOS FRAGMENTS UTILIZANDO ESTA INFORMACIÓN
        List<Fondo> listColores = new ArrayList<>();
        listColores.add(new Fondo("azul",Color.BLUE));
        listColores.add(new Fondo("rojo", Color.RED));
        listColores.add(new Fondo("verde", Color.GREEN));
        listColores.add(new Fondo("amarillo",Color.YELLOW));


        //LE SETEO EL ADAPTER AL VIEW PAGER, EL ADAPTER UTILIZA EL FRAGMENT MANAGER PARA CARGAR FRAGMENT
        // Y LA LISTA DE COLORES PARA CREAR LOS FRAGMENTS CORRESPONDIENTES
        AdapterViewPager adapterViewPager = new AdapterViewPager(getSupportFragmentManager(), listColores);
        viewPager.setAdapter(adapterViewPager);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);
    }
}
