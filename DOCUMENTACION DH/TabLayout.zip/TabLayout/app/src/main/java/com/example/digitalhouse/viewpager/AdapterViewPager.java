package com.example.digitalhouse.viewpager;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by digitalhouse on 27/05/17.
 */

public class AdapterViewPager extends FragmentStatePagerAdapter {

    //EL ADAPTER NECESITA SIEMPRE UNA LISTA DE FRAGMENTS PARA MOSTRAR
    private List<Fragment> fragmentList;

    //EL ADAPTER TAMBIEN CONOSE LAE FUE CREADO PARA PODER SACARLES EL ATRIBUTO NOMBRE
    private List<Fondo> listaColores;


    public AdapterViewPager(FragmentManager fm, List<Fondo> listaDeColores) {
        super(fm);


        listaColores = listaDeColores;
        //INICIALIZO LA LISTA DE FRAGMENT
        fragmentList = new ArrayList<>();

        //LE CARGO LOS FRAGMENTS QUE QUIERO. UTILIZO LA LISTA DE COLORES PARA CREAR
        // LOS FRAGMENTS.
        for(Fondo color : listaDeColores){
            fragmentList.add(ColorFragment.fragmentColorCreator(color.getColor()));
        }

        //LE AVISO AL ADAPTER QUE CAMBIO SU LISTA DE FRAGMENTS.
        notifyDataSetChanged();
    }

    //ESTE METODO DEVUELVE EL FRAGMENT QUE SE ENCUENTRA EN LA POSICION "POSITION" Y
    // SE MUESTRA EN PANTALLA EN ESE MOMENTO:
    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    //ESTE METODO DEVUELVE LA CANTIDAD DE FRAGMENTS QUE SE MOSTRARÁN POR PANTALLA
    @Override
    public int getCount() {
        return fragmentList.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return listaColores.get(position).getNombreColor();
    }
}
