package com.example.digitalhouse.viewpager;

/**
 * Created by digitalhouse on 06/06/17.
 */

public class Fondo {

    private String nombreColor;
    private Integer color;

    public Fondo(String nombreColor, Integer color) {
        this.nombreColor = nombreColor;
        this.color = color;
    }

    public String getNombreColor() {
        return nombreColor;
    }

    public Integer getColor() {
        return color;
    }
}
