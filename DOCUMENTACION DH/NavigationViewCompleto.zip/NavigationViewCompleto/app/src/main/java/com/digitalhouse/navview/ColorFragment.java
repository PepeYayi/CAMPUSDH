package com.digitalhouse.navview;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class ColorFragment extends Fragment {
    private static final String COLOR_KEY = "colorKey";


    public static ColorFragment createFragment(String color){
        ColorFragment colorFragment = new ColorFragment();
        Bundle bundle = new Bundle();
        bundle.putString(COLOR_KEY, color);
        colorFragment.setArguments(bundle);
        return colorFragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Bundle bundle = getArguments();
        String color = bundle.getString(COLOR_KEY);

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_color, container, false);
        view.findViewById(R.id.root).setBackgroundColor(Color.parseColor(color));

        return view;
    }

}
