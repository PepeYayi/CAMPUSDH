package com.example.dh.loginfirebase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DatabaseActivity extends AppCompatActivity {

    public static final String CONTACTOS = "Contactos";
    // Write a message to the database
    FirebaseDatabase database;


    EditText editTextID;
    EditText editTextNombre;
    EditText editTextApellido;
    EditText editTextTelfono;

    Button botonCargarUsuario;
    Button botonTraerLista;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);
        // Write a message to the database
        database = FirebaseDatabase.getInstance();

        editTextID = findViewById(R.id.editTextID);
        editTextNombre = findViewById(R.id.editTextNombre);
        editTextApellido = findViewById(R.id.editTextApellido);
        editTextTelfono = findViewById(R.id.editTextTelefono);

        botonCargarUsuario = findViewById(R.id.BotonCargarContacto);
        botonTraerLista = findViewById(R.id.BotonTraerContactos);

        botonCargarUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Contacto contacto = new Contacto(editTextID.getText().toString(),editTextNombre.getText().toString(),editTextApellido.getText().toString(),editTextTelfono.getText().toString());
                cargarContacto(contacto);
            }
        });

        botonTraerLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                traerTodosLosContactos();
            }
        });




    }

    private void cargarContacto(Contacto contacto){
        DatabaseReference reference = database.getReference()
                .child(CONTACTOS)
                .push();



        reference.setValue(contacto);

    }

    private void traerTodosLosContactos(){

        DatabaseReference reference = database.getReference().child(CONTACTOS);


        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                List<Contacto> contactosList = new ArrayList<>();



                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Contacto contacto = snapshot.getValue(Contacto.class);
                    contactosList.add(contacto);
                }

                Toast.makeText(DatabaseActivity.this, contactosList.toString(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(DatabaseActivity.this, "Fallo", Toast.LENGTH_SHORT).show();
            }
        });
    }




}
