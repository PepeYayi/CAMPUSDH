package EjercicioAdicional;

import java.util.ArrayList;

/**
 * Created by digitalhouse on 15/03/17.
 */
public class Estadio {
    //Atributos
    private ArrayList<Prueba> pruebas = new ArrayList<>();

    //Métodos
    public void agregarPrueba(Prueba prueba){
        pruebas.add(prueba);
    }

    public ArrayList<Prueba> comoLeFue(Atleta atleta){
        ArrayList<Prueba> pruebasQuePaso = new ArrayList<>();
        for(Integer i = 0; i < pruebas.size(); i++){
            Prueba prueba = pruebas.get(i);
            if (prueba.puedeRealizar(atleta)){
                pruebasQuePaso.add(prueba);
            }
        }
        return pruebasQuePaso;
    }

    public Integer quienSeLlevaLaMedallaDeOro(Atleta atletaA, Atleta atletaB){
        Integer countA = 0;
        Integer countB = 0;
        for (Integer i = 0; i < pruebas.size(); i++){
            Prueba prueba = pruebas.get(i);
            Integer res = prueba.quienLaRealizaMejor(atletaA, atletaB);

            if (res < 0){
                countA = countA + 1;
            } else if (res > 0){
                countB = countB + 1;
            }
        }

        if (countA > countB){
            return -1;
        } else if (countB > countA){
            return 1;
        } else {
            return 0;
        }
    }

}
