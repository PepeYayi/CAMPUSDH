package EjercicioAdicional;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Atleta {
    private String nombre;
    private Integer nivel;
    private Integer energia;

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNivel(Integer nivel) {
        this.nivel = nivel;
    }

    public void setEnergia(Integer energia) {
        this.energia = energia;
    }

    public String getNombre() {
        return nombre;
    }

    public Integer getNivel() {
        return nivel;
    }

    public Integer getEnergia() {
        return energia;
    }
}
