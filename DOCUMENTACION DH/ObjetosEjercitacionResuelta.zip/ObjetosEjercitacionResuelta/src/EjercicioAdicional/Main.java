package EjercicioAdicional;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        //Instancio un atleta
        Atleta atletaNumero1 = new Atleta();
        //Seteo valores a los atributos
        atletaNumero1.setNombre("Pedro");
        atletaNumero1.setEnergia(100);
        atletaNumero1.setNivel(50);

        //Instancio otro atleta
        Atleta atletaNumero2 = new Atleta();
        //Seteo valores a los atributos
        atletaNumero2.setNombre("Santiago");
        atletaNumero2.setEnergia(60);
        atletaNumero2.setNivel(25);

        //Instancio una prueba
        Prueba pruebaNumero1 = new Prueba();
        //Seteo valores a los atributos
        pruebaNumero1.setDificultadRequerida(60);
        pruebaNumero1.setEnergiaRequerida(40);

        //Instancio otra prueba
        Prueba pruebaNumero2 = new Prueba();
        //Seteo valores a los atributos
        pruebaNumero2.setEnergiaRequerida(80);
        pruebaNumero2.setDificultadRequerida(20);

        //Instancio una tercer cuenta
        Prueba pruebaNumero3 = new Prueba();
        //Seteo valores a los atributos
        pruebaNumero3.setDificultadRequerida(15);
        pruebaNumero3.setEnergiaRequerida(40);

        //Imprimo por pantalla si el atleta numero 1 pudo realizar cada una de las pruebas
        System.out.println("El atleta " + atletaNumero1.getNombre() +  " puede realizar la prueba 1? " + pruebaNumero1.puedeRealizar(atletaNumero1));
        System.out.println("El atleta " + atletaNumero1.getNombre() +  " puede realizar la prueba 2? " + pruebaNumero2.puedeRealizar(atletaNumero1));
        System.out.println("El atleta " + atletaNumero1.getNombre() +  " puede realizar la prueba 3? " + pruebaNumero3.puedeRealizar(atletaNumero1));

        //Imprimo por pantalla si el atleta numero 2 pudo realizar cada una de las pruebas
        System.out.println("El atleta " + atletaNumero2.getNombre() +  " puede realizar la prueba 1? " + pruebaNumero1.puedeRealizar(atletaNumero2));
        System.out.println("El atleta " + atletaNumero2.getNombre() +  " puede realizar la prueba 2? " + pruebaNumero2.puedeRealizar(atletaNumero2));
        System.out.println("El atleta " + atletaNumero2.getNombre() +  " puede realizar la prueba 3? " + pruebaNumero3.puedeRealizar(atletaNumero2));


        Estadio estadio = new Estadio();
        estadio.agregarPrueba(pruebaNumero1);
        estadio.agregarPrueba(pruebaNumero2);
        estadio.agregarPrueba(pruebaNumero3);

        ArrayList<Prueba> pruebasAtletaN1 = estadio.comoLeFue(atletaNumero1);
        ArrayList<Prueba> pruebasAtletaN2 = estadio.comoLeFue(atletaNumero2);

        Integer resultado = estadio.quienSeLlevaLaMedallaDeOro(atletaNumero1, atletaNumero2);

        if (resultado < 0){
            System.out.println("El atleta " + atletaNumero1.getNombre() + " se lleva la medalla de oro.");
        } else if (resultado > 0){
            System.out.println("El atleta " + atletaNumero2.getNombre() + " se lleva la medalla de oro.");
        }  else {
            System.out.println("Empate!!!");
        }

    }
}
