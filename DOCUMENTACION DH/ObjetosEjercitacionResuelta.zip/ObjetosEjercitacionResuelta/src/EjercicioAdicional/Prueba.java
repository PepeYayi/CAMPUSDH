package EjercicioAdicional;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Prueba {
    private Integer dificultadRequerida;
    private Integer energiaRequerida;

    public void setDificultadRequerida(Integer dificultadRequerida) {
        this.dificultadRequerida = dificultadRequerida;
    }

    public void setEnergiaRequerida(Integer energiaRequerida) {
        this.energiaRequerida = energiaRequerida;
    }

    public Boolean puedeRealizar (Atleta atleta){
        //Devuelvo true o false si dependiendo si se cumple con ambas condiciones
        return atleta.getEnergia() >= energiaRequerida && atleta.getNivel() >= dificultadRequerida;
    }

    public Integer quienLaRealizaMejor(Atleta atletaA, Atleta atletaB){
        if (puedeRealizar(atletaA) && !puedeRealizar(atletaB)){
            return -1;
        } else if (!puedeRealizar(atletaA) && puedeRealizar(atletaB)){
            return 1;
        } else if (puedeRealizar(atletaA) && puedeRealizar(atletaB)) {
            if (atletaA.getNivel() > atletaB.getNivel()){
                return -1;
            } else if (atletaA.getNivel() < atletaB.getNivel()){
                return 1;
            }
        }

        return 0;
    }

}
