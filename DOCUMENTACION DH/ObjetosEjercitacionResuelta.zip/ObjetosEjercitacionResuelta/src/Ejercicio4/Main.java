package Ejercicio4;

public class Main {

    public static void main(String[] args) {
        Tripode unTripode = new Tripode();
        unTripode.setAlturaMaxima(50.0);
        unTripode.setAlturaMinima(10.0);
        unTripode.setPlegado(true);

        unTripode.plegar();
        unTripode.definirAltura(20.0);
        unTripode.guardar();
        unTripode.desplegar();
        unTripode.listoParaGuardar();
        unTripode.usar();
        unTripode.guardar();
        unTripode.listoParaUsar();

    }
}
