package Ejercicio4;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Tripode {
    private Boolean plegado;
    private Double alturaMinima;
    private Double alturaMaxima;
    private Double alturaActual;

    public void definirAltura(Double unaAltura){

        if(unaAltura <= alturaMaxima && unaAltura >= alturaMinima){
            alturaActual = unaAltura;
            System.out.println("Hay definido la altura del trípode en " + alturaActual + "cm.");
        }else if(unaAltura < alturaMinima){
            System.out.println("La altura seleccionada es menor a la altura mínima del trípode.");
            System.out.println("No se ha cambiado la altura del trípode");
            System.out.println("La altura actual del trípode es " + alturaActual + "cm.");
        }else if(unaAltura > alturaMaxima){
            System.out.println("La altura seleccionada es mayor a la altura máxima del trípode.");
            System.out.println("No se ha cambiado la altura del trípode");
            System.out.println("La altura actual del trípode es " + alturaActual + "cm.");
        }
    }

    public void plegar(){
        plegado = true;
        System.out.println("Se ha plegado el trípode.");
    }

    public void desplegar(){
        plegado = false;
        System.out.println("Se ha desplegado el trípode.");
    }

    public void guardar(){
        plegar();
        alturaActual = alturaMinima;
        System.out.println("El trípode está listo para ser guardado.");
    }

    public Boolean listoParaGuardar(){
        if (plegado && alturaActual.equals(alturaMinima)){
            System.out.println("El trípode está listo para ser guardado.");
            return true;
        } else {
            System.out.println("El trípode no está listo para ser guardado");
            return false;
        }

    }

    public void usar(){
        desplegar();
        alturaActual = alturaMaxima/2 + 0.01;
        System.out.println("El trípode está listo para ser usado.");

    }

    public Boolean listoParaUsar(){
        if(alturaActual > alturaMaxima/2 && !plegado){
            System.out.println("El trípode está listo para ser usado");
            return true;
        } else {
            System.out.println("El trípode no está listo para ser usado.");
            return false;
        }

    }

    public void setPlegado(Boolean plegado) {
        this.plegado = plegado;
    }

    public void setAlturaMinima(Double alturaMinima) {
        this.alturaMinima = alturaMinima;
    }

    public void setAlturaMaxima(Double alturaMaxima) {
        this.alturaMaxima = alturaMaxima;
    }

    public void setAlturaActual(Double alturaActual) {
        this.alturaActual = alturaActual;
    }
}
