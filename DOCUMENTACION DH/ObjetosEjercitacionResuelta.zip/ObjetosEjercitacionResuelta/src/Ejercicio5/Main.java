package Ejercicio5;

public class Main {

    public static void main(String[] args) {
        //Instancio un nuevo vehiculo
        Vehiculo unVehiculo = new Vehiculo("Ford", "Fiesta", 2006,"Gris", 165078.65);
        //Instancio un nuevo cliente
        Cliente unCliente = new Cliente("Juan", "Suarez","juan@hotmail.com");

        //Instancio una concesionaria
        Concesionaria concesionaria = new Concesionaria();
        //Registro una nueva venta
        concesionaria.registrarVenta(unVehiculo,unCliente,85780.0);
    }
}
