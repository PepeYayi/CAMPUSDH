package Ejercicio5;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Venta {
    private Double montoVenta;
    private Vehiculo vehiculoVendido;
    private Cliente cliente;

    public Venta(Double montoVenta, Vehiculo vehiculoVendido, Cliente cliente) {
        this.montoVenta = montoVenta;
        this.vehiculoVendido = vehiculoVendido;
        this.cliente = cliente;
    }

    public Double getMontoVenta() {
        return montoVenta;
    }

    public Vehiculo getVehiculoVendido() {
        return vehiculoVendido;
    }

    public Cliente getCliente() {
        return cliente;
    }
}
