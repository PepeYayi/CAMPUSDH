package Ejercicio5;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Concesionaria {

    public void registrarVenta(Vehiculo vehiculo, Cliente cliente, Double monto){
        //Instancio una nueva venta y le asigno los valores correspondientes
        Venta unaVenta = new Venta(monto,vehiculo,cliente);
        System.out.println("Se registro una nueva venta a nombre de: " + unaVenta.getCliente().getNombre() + " " + unaVenta.getCliente().getApellido());
        System.out.println("Compro un auto marca " + unaVenta.getVehiculoVendido().getMarca() + ", modelo " + unaVenta.getVehiculoVendido().getModelo() + ", color " + unaVenta.getVehiculoVendido().getColor());
        System.out.println("El monto de la venta es de $" + unaVenta.getMontoVenta());
    }
}
