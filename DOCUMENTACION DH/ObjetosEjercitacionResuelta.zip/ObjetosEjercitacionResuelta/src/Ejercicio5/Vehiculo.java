package Ejercicio5;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Vehiculo {
    private String marca;
    private String modelo;
    private Integer anioDeFabricacion;
    private String color;
    private Double kilometraje;

    public Vehiculo(String marca, String modelo, Integer anioDeFabricacion, String color, Double kilometraje) {
        this.marca = marca;
        this.modelo = modelo;
        this.anioDeFabricacion = anioDeFabricacion;
        this.color = color;
        this.kilometraje = kilometraje;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public Integer getAnioDeFabricacion() {
        return anioDeFabricacion;
    }

    public String getColor() {
        return color;
    }

    public Double getKilometraje() {
        return kilometraje;
    }
}
