package Ejercicio5;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Cliente {
    private String nombre;
    private String apellido;
    private String datoDeContacto;

    public Cliente(String nombre, String apellido, String datoDeContacto) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.datoDeContacto = datoDeContacto;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

}
