package Ejercicio1;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Cliente {
    private String nombre;
    private String apellido;

    //Setter del nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    //Setter del apellido
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
}
