package Ejercicio1;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Cuenta {
    private String numeroDeCuenta;
    private Integer saldo;
    private Cliente titular;

    //Setter del numero de cuenta
    public void setNumeroDeCuenta(String numeroDeCuenta) {
        this.numeroDeCuenta = numeroDeCuenta;
    }

    //Setter del cliente de la cuenta
    public void setTitular(Cliente titular) {
        this.titular = titular;
    }

    //Setter del saldo
    public void setSaldo(Integer saldo) {
        this.saldo = saldo;
    }

    //Metodo para el deposito
    public void deposito (Integer dineroADepositar) {
        //actualizo el saldo sumandole el valor del dineroADepositar
        saldo = saldo + dineroADepositar;
        //Imprimo por pantalla el nuevo valor del saldo
        System.out.println("Su saldo es de " + saldo);
    }

    //Metodo para la extraccion
    public void extraccion (Integer dineroAExtraer){

        //Pregunto si el saldo es menor que la cantidad de diner a extraer
        if (saldo < dineroAExtraer){
            //Imprimo por pantalla que no se puede realizar la extracción
            System.out.println("Fondos insuficientes");
        }else{
            //Si el saldo es mayor al dineroAExtrar le resto el dinero al saldo
            saldo = saldo - dineroAExtraer;
            //Imprimo por pantalla el valor del saldo
            System.out.println("Su saldo es de " + saldo);
        }
    }

}
