package Ejercicio1;

public class Main {

    public static void main(String[] args) {

        //Instancio un nuevo cliente
        Cliente cliente = new Cliente();
        //Le seteo el nombre
        cliente.setNombre("Juan");
        //Le seteo el apellido
        cliente.setApellido("Perez");

        //Instancio una nueva cuenta
        Cuenta cuenta = new Cuenta();
        //Seteo un numero de cuenta
        cuenta.setNumeroDeCuenta("000-92929292");
        //Seteo el cliente a la nueva cuenta
        cuenta.setTitular(cliente);
        //Seteo un saldo
        cuenta.setSaldo(4000);

        //Instancio otro cliente
        Cliente otroCliente = new Cliente();
        //Le seteo el nombre
        otroCliente.setNombre("Jorge");
        //Le seteo el apellido
        otroCliente.setApellido("Gomez");

        //Instancio otro cuenta
        Cuenta otraCuenta = new Cuenta();
        //Seteo un numero de cuenta
        otraCuenta.setNumeroDeCuenta("000-45454545");
        //Seteo el cliente de la cuenta
        otraCuenta.setTitular(otroCliente);
        //Seteo un saldo
        otraCuenta.setSaldo(7000);

        //Hago un deposito en la primer cuenta
        cuenta.deposito(500);
        //Hago un deposito en la segunda cuenta
        otraCuenta.deposito(3400);

        //Hago una extracción en la primer cuenta
        cuenta.extraccion(100000);
        //Hago una extracción en la segunda cuenta
        otraCuenta.extraccion(650);
    }
}
