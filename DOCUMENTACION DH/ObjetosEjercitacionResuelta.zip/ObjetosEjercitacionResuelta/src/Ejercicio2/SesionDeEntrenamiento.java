package Ejercicio2;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class SesionDeEntrenamiento {
    private Integer otorgarExperiencia;

    public void setOtorgarExperiencia(Integer otorgarExperiencia) {
        this.otorgarExperiencia = otorgarExperiencia;
    }

    public void entrenarA(JugadorDeFutbol unJugador){
        //Hago correr al jugador que me pasan por parametro
        unJugador.correr();
        //Hago hacer un gol al jugador que me pasan por parametro
        unJugador.hacerGol();
        //Hago correr al jugador que me pasan por parametro nuevamente
        unJugador.correr();
        //Imprimo por pantalla la experiencia que tiene el jugador
        System.out.println("La experiencia del jugador era de: " + unJugador.getExperiencia());
        //Le sumo al jugador el valor de la experiencia que otorga el entrenamiento
        unJugador.setExperiencia(unJugador.getExperiencia()+otorgarExperiencia);
        //Imprimo por pantalla la experiencia nueva
        System.out.println("La experiencia actual del jugador es de: " + unJugador.getExperiencia());
    }

}
