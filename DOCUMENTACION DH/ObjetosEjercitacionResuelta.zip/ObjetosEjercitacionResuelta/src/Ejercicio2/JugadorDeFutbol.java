package Ejercicio2;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class JugadorDeFutbol {
    private String nombre;
    private Integer energia;
    private Integer felicidad;
    private Integer goles;
    private Integer experiencia;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEnergia(Integer energia) {
        this.energia = energia;
    }

    public void setFelicidad(Integer felicidad) {
        this.felicidad = felicidad;
    }

    public void setGoles(Integer goles) {
        this.goles = goles;
    }

    public void setExperiencia(Integer experiencia) {
        this.experiencia = experiencia;
    }

    public Integer getExperiencia() {
        return experiencia;
    }

    public void hacerGol (){
        //Sumo a la energia
        energia = energia - 5;
        //Sumo a la felicidad
        felicidad = felicidad + 10;
        //Sumo a los goles
        goles = goles + 1;
        //Imprimo por pantalla
        System.out.println("GOOOOOOOOOOOOOOL!");
    }

    public void correr(){
        //Resto a la energía
        energia = energia - 10;
        //Imprimo por pantalla
        System.out.println("No me dan más las piernas!");
    }

}
