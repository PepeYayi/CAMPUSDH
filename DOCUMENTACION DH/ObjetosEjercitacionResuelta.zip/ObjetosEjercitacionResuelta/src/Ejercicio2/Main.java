package Ejercicio2;

public class Main {

    public static void main(String[] args) {

        //Instancio un jugador de futbol
        JugadorDeFutbol jugadorNumero1 = new JugadorDeFutbol();
        //Seteo los valores para sus atributos
        jugadorNumero1.setNombre("Messi");
        jugadorNumero1.setExperiencia(1500);
        jugadorNumero1.setEnergia(100);
        jugadorNumero1.setFelicidad(0);
        jugadorNumero1.setGoles(0);

        //Instancio otro jugador de futbol
        JugadorDeFutbol jugadorNumero2 = new JugadorDeFutbol();
        //Seteo los valores para sus atributos
        jugadorNumero2.setNombre("Neymar");
        jugadorNumero2.setExperiencia(850);
        jugadorNumero2.setEnergia(100);
        jugadorNumero2.setFelicidad(60);
        jugadorNumero2.setGoles(0);

        //Instancio una sesion de entrenamiento
        SesionDeEntrenamiento sesionDeEntrenamiento = new SesionDeEntrenamiento();

        //Seteo un valor a la experiencia que va a otorgar la sesion
        sesionDeEntrenamiento.setOtorgarExperiencia(200);
        //Imprimo por pantalla el nombre del jugador
        System.out.println("- Sesion de entrenamiento del jugador " + jugadorNumero1.getNombre() + " -");
        //Entreno al jugador 1
        sesionDeEntrenamiento.entrenarA(jugadorNumero1);

        //Seteo otro valor a la experiencia que va a otorgar la sesion
        sesionDeEntrenamiento.setOtorgarExperiencia(150);
        //Imprimo por pantalla el nombre del jugador
        System.out.println("- Sesion de entrenamiento del jugador " + jugadorNumero2.getNombre() + " -");
        //Entreno al jugador 2
        sesionDeEntrenamiento.entrenarA(jugadorNumero2);
    }
}
