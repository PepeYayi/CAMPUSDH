package com.example.collapseappbar;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //LISTA DE PERSONAJES


        PersonajesAdapter personajesAdapter = new PersonajesAdapter(getPersonajesList());
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler);
        recyclerView.setAdapter(personajesAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
    }

    private List<Personaje> getPersonajesList() {
        List<Personaje> personajeList = new ArrayList<Personaje>();
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        personajeList.add(new Personaje("Superman"));
        return personajeList;

    }
}
