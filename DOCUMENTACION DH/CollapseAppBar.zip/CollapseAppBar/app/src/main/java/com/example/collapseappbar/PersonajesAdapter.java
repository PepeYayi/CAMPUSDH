package com.example.collapseappbar;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by ma on 11/10/17.
 */

public class PersonajesAdapter extends RecyclerView.Adapter{

    private Context context;
    private List<Personaje> personajeList;

    public PersonajesAdapter(List<Personaje> personajeList) {
        this.personajeList = personajeList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        //INFLAR UNA VISTA, CREAR UN VIEWHOLDER Y DEVOLVER EL VIEW HOLDER
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View view = inflater.inflate(R.layout.recycler_view_celda, parent, false);

        PersonajeViewHolder personajeViewHolder = new PersonajeViewHolder(view);

        return personajeViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        PersonajeViewHolder personajeViewHolder = (PersonajeViewHolder) holder;
        Personaje personajeAMostrar = personajeList.get(position);
        personajeViewHolder.cargarPersonaje(personajeAMostrar);
    }

    @Override
    public int getItemCount() {
        return personajeList.size();
    }


    private class PersonajeViewHolder extends RecyclerView.ViewHolder{

        private TextView textViewDetalle;

        public PersonajeViewHolder(View itemView) {
            super(itemView);
            textViewDetalle = (TextView) itemView.findViewById(R.id.textViewDetalle);
        }

        public void cargarPersonaje(Personaje personaje){
            textViewDetalle.setText(personaje.getNombre());
        }
    }

}
