package com.company.ejercicio1;

/**
 * Created by ma on 16/02/18.
 */
public class Cuenta {
    private String numeroDeCuenta;
    private Double saldo;
    private Cliente titular;

    public Cuenta(Double unSaldo){
        saldo = unSaldo;
    }

    public void setSaldo(Double saldoInicial){
        saldo = saldoInicial;
    }

    public void depositar(Double dinero) {
        saldo = saldo + dinero;
        System.out.println("Se hizo un deposito. " +
                "Tu nuevo saldo es de: " + saldo);
    }

    public void extraccion(Double dinero) {
        if (saldo >= dinero) {
            saldo = saldo - dinero;
            System.out.println("Se hizo extraccion fenomeno!. Tu nuevo" +
                    "saldo es de: " + saldo);
        } else {
            System.out.println("Fondos insuficiente");
        }
    }

    public void setTitular(Cliente unCliente){
        titular = unCliente;
    }

    public Cliente getTitular(){
        return titular;
    }

}
