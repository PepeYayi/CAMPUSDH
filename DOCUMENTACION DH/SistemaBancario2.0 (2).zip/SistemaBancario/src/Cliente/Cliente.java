package Cliente;

/**
 * Created by digitalhouse on 13/03/17.
 */
public class Cliente {

    //ATRIBUTOS
    private Integer numeroDeCliente;

    //METODOS
    public Integer getNumeroDeCliente(){
        return numeroDeCliente;
    }
}
