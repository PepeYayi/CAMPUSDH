package com.example.digitalhouse.mvcjsonguiado.View;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.digitalhouse.mvcjsonguiado.Model.Producto;
import com.example.digitalhouse.mvcjsonguiado.R;
import com.example.digitalhouse.mvcjsonguiado.Cotroller.ProductoController;

import java.util.List;

public class ActivityRecyclerViewProductos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_producto_final);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        RecyclerView.Adapter adapter = new RecyclerAdapter(cargarProductos());
        recyclerView.setAdapter(adapter);

    }

    public List<Producto> cargarProductos(){
        ProductoController productoController = new ProductoController();
        return productoController.obtenerProductos(this);
    }
}


