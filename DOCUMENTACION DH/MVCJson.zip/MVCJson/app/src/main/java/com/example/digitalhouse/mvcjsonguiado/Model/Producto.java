package com.example.digitalhouse.mvcjsonguiado.Model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by andres on 10/25/17.
 */

public class Producto {

    @SerializedName("nombre")
    private String name;

    private String descripcion;

    private Double precio;

    public Producto() {
    }

    public Producto(String name, String descripcion, Double precio) {
        this.name = name;
        this.descripcion = descripcion;
    }

    public String getName() {
        return name;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Double getPrecio() {
        return precio;
    }
}
