package com.example.digitalhouse.mvcjsonguiado.DAO;

import android.content.Context;
import android.content.res.AssetManager;

import com.example.digitalhouse.mvcjsonguiado.Model.ContainerProducto;
import com.example.digitalhouse.mvcjsonguiado.Model.Producto;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by digitalhouse on 24/05/17.
 */

public class DAOProductoArchivo {

    public List<Producto> obtenerProductosDeArchivo(Context context){

        List<Producto> productos = new ArrayList<>();

        try {
            //LEER ARCHIVO
            AssetManager manager = context.getAssets();
            InputStream archivoJson = manager.open("productList.json");

            //PARSING DEL ARCHIVO -> GSON
            BufferedReader bufferReaderIn = new BufferedReader(new InputStreamReader(archivoJson));
            Gson gson = new Gson();
            ContainerProducto containerProducto = gson.fromJson(bufferReaderIn, ContainerProducto.class);
            productos = containerProducto.getProducts();

        }
        catch (Exception e){

        }
        return productos;
    }
}
