package com.example.digitalhouse.mvcjsonguiado.DAO;



import com.example.digitalhouse.mvcjsonguiado.Model.Producto;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by digitalhouse on 24/05/17.
 */

public class DAOProductoInternet {

    public List<Producto> obtenerProductosDeInternet(){
        List<Producto> productos = new ArrayList<>();

        return productos;
    }
}
