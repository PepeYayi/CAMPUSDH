package com.example.digitalhouse.mvcjsonguiado.Model;

import java.util.List;

/**
 * Created by andres on 10/25/17.
 */

public class ContainerProducto {

    private List<Producto> products;

    public List<Producto> getProducts() {
        return products;
    }
}
