package com.example.digitalhouse.mvcjsonguiado.View;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.digitalhouse.mvcjsonguiado.Model.Producto;
import com.example.digitalhouse.mvcjsonguiado.R;

import java.util.List;

/**
 * Created by digitalhouse on 02/06/17.
 */

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    private List<Producto> datos;

    public RecyclerAdapter(List<Producto> datos){
        this.datos = datos;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = layoutInflater.inflate(R.layout.item, parent, false);
        ViewHolder viewHolder = new ViewHolder(itemView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Producto producto = datos.get(position);
        holder.cargarDatos(producto);
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public Producto getItem(Integer posicion){
        return datos.get(posicion);
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView nombre;
        private TextView descripcion;
        private TextView precio;

        public ViewHolder(View itemView) {
            super(itemView);
            nombre = (TextView) itemView.findViewById(R.id.textViewNombre);
            descripcion = (TextView) itemView.findViewById(R.id.textViewDescripcion);
            precio = (TextView) itemView.findViewById(R.id.textViewPrecio);
        }

        public void cargarDatos(Producto producto){
            nombre.setText(producto.getName());
            descripcion.setText(producto.getDescripcion());
            precio.setText(producto.getPrecio().toString());
        }
    }
}
