package com.example.digitalhouse.mvcjsonguiado.Cotroller;


import android.content.Context;

import com.example.digitalhouse.mvcjsonguiado.DAO.DAOProductoArchivo;
import com.example.digitalhouse.mvcjsonguiado.DAO.DAOProductoInternet;
import com.example.digitalhouse.mvcjsonguiado.Model.Producto;

import java.util.List;

/**
 * Created by digitalhouse on 24/05/17.
 */

public class ProductoController {


    public List<Producto> obtenerProductos(Context context) {

        List<Producto>productos = null;

        if (hayInternet()) {
            DAOProductoInternet daoProductoInternet = new DAOProductoInternet();
            productos = daoProductoInternet.obtenerProductosDeInternet();
        } else {
            DAOProductoArchivo daoProductoArchivo = new DAOProductoArchivo();
            productos = daoProductoArchivo.obtenerProductosDeArchivo(context);
        }

        return productos;
    }

    public Boolean hayInternet(){
        return false;
    }

}
