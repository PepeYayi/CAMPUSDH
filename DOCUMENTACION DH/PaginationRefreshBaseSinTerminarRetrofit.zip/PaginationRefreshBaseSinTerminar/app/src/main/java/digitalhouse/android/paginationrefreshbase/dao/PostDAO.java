package digitalhouse.android.paginationrefreshbase.dao;

import java.util.List;

import digitalhouse.android.paginationrefreshbase.model.Post;
import digitalhouse.android.paginationrefreshbase.model.PostContainer;
import digitalhouse.android.paginationrefreshbase.util.ResultListener;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * Created by digitalhouse on 6/06/16.
 */
public class PostDAO {

    private Retrofit retrofit;
    private ServiceRetrofit serviceRetrofit;

    public PostDAO() {
        //Retrofit usa OkHttpClient y pido un constructor
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("http://blooming-garden-41675.herokuapp.com/")
                .addConverterFactory(GsonConverterFactory.create());

        retrofit = builder.client(httpClient.build()).build();
        serviceRetrofit = retrofit.create(ServiceRetrofit.class);
    }

    public void getPostsPaginated(final ResultListener<List<Post>> listener,
                                  Integer offset, Integer limit) {
        Call<PostContainer> llamada = serviceRetrofit.getPosts(offset, limit);
        llamada.enqueue(new Callback<PostContainer>() {
            @Override
            public void onResponse(Call<PostContainer> call, Response<PostContainer> response) {
                List<Post> listadoResultado = response.body().getPostList();
                listener.finish(listadoResultado);
            }

            @Override
            public void onFailure(Call<PostContainer> call, Throwable t) {

            }
        });
    }

}




















