package digitalhouse.android.paginationrefreshbase.view;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ProgressBar;

import java.util.List;

import digitalhouse.android.paginationrefreshbase.R;
import digitalhouse.android.paginationrefreshbase.controller.PostController;
import digitalhouse.android.paginationrefreshbase.model.Post;
import digitalhouse.android.paginationrefreshbase.util.ResultListener;


public class MainActivity extends AppCompatActivity {
    //Declaro todas estas variables como globales ya que las voy a usar a lo largo de la clase.
    private RecyclerView recyclerView;
    private AdapterPost adapterPost;
    private LinearLayoutManager linearLayoutManager;
    private PostController postController;
    private Boolean isLoading = false;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        //Seteo el adapter y los elementos del recyclerView
        adapterPost = new AdapterPost(getApplicationContext());
        recyclerView.setAdapter(adapterPost);
        linearLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);

        postController = new PostController();

        getNewPage();

    }

    public void getNewPage() {


        postController.getPostListPaginated(new ResultListener<List<Post>>() {
            @Override
            public void finish(List<Post> resultado) {
                adapterPost.addPostList(resultado);
                adapterPost.notifyDataSetChanged();
            }
        }, MainActivity.this);
    }
}




















