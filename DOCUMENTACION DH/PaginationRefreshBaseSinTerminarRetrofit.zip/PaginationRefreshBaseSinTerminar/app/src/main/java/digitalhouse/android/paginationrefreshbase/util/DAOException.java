package digitalhouse.android.paginationrefreshbase.util;

public class DAOException extends Exception {

	public DAOException(String error)
	{
		super(error);
	}
	
}
