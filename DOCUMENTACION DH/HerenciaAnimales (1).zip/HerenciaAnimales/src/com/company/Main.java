package com.company;

import java.awt.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here

        //Creo un objeto Felino, llamo a su método comer y muestro su niver de energía por pantalla
        Felino gato = new Felino();
        gato.comer(50);
        System.out.println( gato.getEnergia());

        //Creo un objeto Canino, llamo a su método comer y muestro su nivel de energía por pantalla
        Canino perrito = new Canino();
        perrito.comer(1000);
        System.out.println( perrito.getEnergia());


        //Creo una lista de animales
        ArrayList<Animal> animales = new ArrayList<>();
        // Agrego al Canino
        animales.add(perrito);

        // Agrego al Felino
        animales.add(gato);

        // Creo un Loro y lo agrego a la lista
        Loro loro = new Loro();
        animales.add(loro);


        // Recorro la lista y llamo a los comer y quienSoy de cada elemento
        // Ninguno de estos objetos fue declarado como un objeto Animal, pero son todos hijos de Animal
        // Por eso es que reconocen los métodos de más allá de que hayan sido overraideados o no,
        // Es decir, podemos tratar a los hijos como si fueran de la clase padre (de hecho lo son)
        // A esto se le llama Polimorfismo
        for(Integer i = 0; i < animales.size(); i++){
            System.out.println("-------------------");
            animales.get(i).comer(50);
            animales.get(i).quienSoy();
            System.out.println( animales.get(i).getEnergia());
        }

    }
}
