package com.company;

// Creamos la clase Animal
public class Animal {

    //Atributos

    // En este caso declaramos los atributos con visibilidad protected que le dá acceso solo a los
    // hijos de esta clase
    protected Integer energia = 0;

    //Métodos
    public void quienSoy(){
        System.out.println("SOY UN ANIMAL");
    }

    public void comer(Integer comida){
        energia = energia + comida;
    }


    //Getters y Setters (Que también son métodos pero van al fondo por lo general)
    public Integer getEnergia() {
        return energia;
    }
}
