package com.company;

// Declaro la clase Loro y la hago heredar de Animal con extends, esto hace que Loro sea clase
// hija de Animal
public class Loro extends Animal {


    // Sobreescribo u Overraideo el método quienSoy para que la clase Loro tenga su propio saludo
    // en este caso: "SOY UN LORO", en vez de el del padre: "SOY UN ANIMAL"
    @Override
    public void quienSoy() {
        System.out.println("SOY UN LORO");
    }
}
