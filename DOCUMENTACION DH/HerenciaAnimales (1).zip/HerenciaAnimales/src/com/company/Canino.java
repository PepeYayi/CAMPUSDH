package com.company;

// Declaro la clase Canino y la hago heredar de Animal con extends, ésto hace que Canino sea clase
// hija de Animal
public class Canino extends Animal {


    // Sobreescribo u Overraideo el método quienSoy para que la clase Canino tenga su propio saludo
    // en este caso: "SOY UN PERRO", en vez de el del padre: "SOY UN ANIMAL"
    @Override
    public void quienSoy() {
        System.out.println("SOY UN PERRO");
    }


    // Sobreescribo u Overraideo el método comer para que la clase Canino obtenga el triple de
    // energía al comer que su clase padre
    @Override
    public void comer(Integer comida) {
        energia = energia + comida*3;
    }
}
