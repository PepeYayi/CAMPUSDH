package com.company;

// Declaro la clase Felino y la hago heredar de Animal con extends, esto hace que Felino sea clase 
// hija de Animal
public class Felino extends Animal{


    // Sobreescribo u Overraideo el método quienSoy para que la clase Felino tenga su propio saludo
    // en este caso: "SOY UN GATO", en vez de el del padre: "SOY UN ANIMAL"
    @Override
    public void quienSoy() {
        super.quienSoy();
        System.out.println("SOY UN GATO");
    }


    // Sobreescribo u Overraideo el método comer para que la clase Felino obtenga el doble de
    // energía al comer que su clase padre
    @Override
    public void comer(Integer comida) {
        energia = energia + comida*2;
    }
}
