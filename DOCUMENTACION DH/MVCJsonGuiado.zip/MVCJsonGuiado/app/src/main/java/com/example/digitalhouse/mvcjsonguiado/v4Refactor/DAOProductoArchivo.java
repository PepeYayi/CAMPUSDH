package com.example.digitalhouse.mvcjsonguiado.v4Refactor;


import java.util.List;

/**
 * Created by digitalhouse on 24/05/17.
 */

public class DAOProductoArchivo {

    public List<Producto> obtenerProductosDeArchivo(){
        List<Producto>productos = null;
        //Obtengo algun objeto que me permite hacer comunicaciones con Internet
        //Le pido que se conecte con Mercado Abierto
        //esto me devuelve un choclo de texto con tota la informacion
        //tengo que pasarla a una lista de productos y luego devolverla
        return productos;
    }
}
