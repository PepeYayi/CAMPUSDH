package com.example.comunicacion;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by ma on 26/03/18.
 */

public class RegisterActivity extends AppCompatActivity {
}
