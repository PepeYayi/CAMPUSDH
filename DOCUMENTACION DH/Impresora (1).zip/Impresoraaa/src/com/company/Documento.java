package com.company;

public class Documento implements Imprimible {

    @Override
    public void imprimir() {
        System.out.println("soy un documento");
    }
}
