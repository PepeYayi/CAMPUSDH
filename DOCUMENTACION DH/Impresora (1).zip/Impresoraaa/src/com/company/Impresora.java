package com.company;

import java.util.ArrayList;
import java.util.List;

public class Impresora {

    private List<Imprimible> cosasAImprimir;

    public Impresora() {
        cosasAImprimir = new ArrayList<>();
    }

    public void agregarACola(Imprimible unImprimible){
        cosasAImprimir.add(unImprimible);
    }

    public void imprimirImprimibles(List<Imprimible> cosasImportantes){

        for (Imprimible unaCosaImportante : cosasImportantes) {
            unaCosaImportante.imprimir();
        }

    }

    public void imprimir(){

        for(int i =0 ; i < cosasAImprimir.size(); i++){
           Imprimible unImprimible = cosasAImprimir.get(i);
            unImprimible.imprimir();
        }

        for (Imprimible unImprimible :cosasAImprimir) {
            unImprimible.imprimir();
        }




    }

}
