package com.company;

public interface Imprimible {
    public void imprimir();
}
