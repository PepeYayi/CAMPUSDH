package com.company;

public class Presupuesto implements Imprimible {

    @Override
    public void imprimir() {
        System.out.println("soy un documento");
    }
}
