package com.company;

public class Foto implements Imprimible {

    @Override
    public void imprimir() {
        System.out.println("soy una foto");
    }
}
