package com.company;

public class Animal {

    public void comer(){

    }
}
