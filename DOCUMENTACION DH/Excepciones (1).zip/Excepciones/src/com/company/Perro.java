package com.company;

public class Perro extends Animal {

    public void buscarPelota(){


    }
}
