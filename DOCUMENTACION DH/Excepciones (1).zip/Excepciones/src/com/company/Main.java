package com.company;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
	// write your code here

        try{
            Integer numeroA = 10;
            System.out.println("Numero A: " + numeroA);
            Integer numeroB = 10;
            Integer resultado = numeroA / numeroB;
            System.out.println("El resultado es: " + resultado);

            Perro perro = new Perro();
            Gato gato = new Gato();
            List<Animal> animals = new ArrayList<>();
            animals.add(perro);
            animals.add(gato);
            Perro perrito = (Perro) animals.get(1);
        }
        catch (NullPointerException e) {
            e.printStackTrace();
            System.out.println("Te surgio un error de NULL");
        }
        catch (ArithmeticException e) {
            e.printStackTrace();
            System.out.println("Te surgio un error de matematica");
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println("Te surgio un error");
        }
        System.out.println("Llegue acaa");
    }
}
