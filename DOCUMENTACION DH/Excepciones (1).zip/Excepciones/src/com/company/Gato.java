package com.company;

public class Gato extends Animal {

    public void buscarPelota(){


    }
}
