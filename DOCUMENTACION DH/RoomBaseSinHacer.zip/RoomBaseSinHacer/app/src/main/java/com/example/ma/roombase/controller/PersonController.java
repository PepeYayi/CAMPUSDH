package com.example.ma.roombase.controller;

import android.content.Context;

import com.example.ma.roombase.dao.Person;
import com.example.ma.roombase.dao.PersonDaoUtil;
import com.example.ma.roombase.util.ResultListener;

import java.util.List;

/**
 * Created by Nicolas Dubiansky on 16/01/18.
 */

public class PersonController {
    public void deletePerson(Context context, Person person, final ResultListener<Boolean> resultListener) {
        PersonDaoUtil personDaoUtil = new PersonDaoUtil(context);
        personDaoUtil.deletePerson(person, new ResultListener<Boolean>() {
            @Override
            public void finish(Boolean resultado) {
                resultListener.finish(resultado);
            }
        });
    }

    public void insertPerson(Context context, Person person, final ResultListener<Long> resultListener) {
        PersonDaoUtil personDaoUtil = new PersonDaoUtil(context);
        personDaoUtil.insertPerson(person, new ResultListener<Long>() {
            @Override
            public void finish(Long resultado) {
                resultListener.finish(resultado);
            }
        });
    }

    public void getAllPersons(Context context, final ResultListener<List<Person>> resultListener) {
        PersonDaoUtil personDaoUtil = new PersonDaoUtil(context);
        personDaoUtil.getAllPersons(new ResultListener<List<Person>>() {
            @Override
            public void finish(List<Person> resultado) {
                resultListener.finish(resultado);
            }
        });
    }

    public void updatePerson(Context context, Person person, final ResultListener<Boolean> resultListener) {
        PersonDaoUtil personDaoUtil = new PersonDaoUtil(context);
        personDaoUtil.updatePerson(person, new ResultListener<Boolean>() {
            @Override
            public void finish(Boolean resultado) {
                resultListener.finish(resultado);
            }
        });
    }
}
