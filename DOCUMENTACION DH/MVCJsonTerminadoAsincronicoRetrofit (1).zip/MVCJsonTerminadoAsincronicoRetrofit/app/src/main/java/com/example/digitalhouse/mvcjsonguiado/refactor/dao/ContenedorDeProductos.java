package com.example.digitalhouse.mvcjsonguiado.refactor.dao;

import java.util.List;

/**
 * Created by DH on 3/4/2018.
 */

public class ContenedorDeProductos {
    private List<Producto> results;

    public List<Producto> getResults() {
        return results;
    }
}
