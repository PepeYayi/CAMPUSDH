package com.example.digitalhouse.mvcjsonguiado.refactor.dao;

import com.example.digitalhouse.mvcjsonguiado.refactor.utils.ResultListener;

import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by DH on 3/4/2018.
 */

public class DAOProductoRetrofit {
    private Retrofit retrofit;

    public DAOProductoRetrofit(){
        //Retrofit usa OkHttpClient y pido un constructor
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("https://api.mercadolibre.com/")
                .addConverterFactory(GsonConverterFactory.create());

        retrofit = builder.client(httpClient.build()).build();

    }

    public void obtenerProductosDeInternetAsincronico(final ResultListener<List<Producto>> escuchadorDelControlador){
        ServiceProducto serviceProducto = retrofit.create(ServiceProducto.class);
        Call<ContenedorDeProductos> llamada = serviceProducto.getProductos("futbol");
        llamada.enqueue(new Callback<ContenedorDeProductos>() {
            @Override
            public void onResponse(Call<ContenedorDeProductos> call, Response<ContenedorDeProductos> response) {
                escuchadorDelControlador.finish(response.body().getResults());
            }

            @Override
            public void onFailure(Call<ContenedorDeProductos> call, Throwable t) {
                escuchadorDelControlador.finish(new ArrayList<Producto>());
            }
        });


    }


}
