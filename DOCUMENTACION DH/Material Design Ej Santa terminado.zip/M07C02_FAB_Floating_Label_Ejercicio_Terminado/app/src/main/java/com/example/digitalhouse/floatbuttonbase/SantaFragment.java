package com.example.digitalhouse.floatbuttonbase;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import static android.support.design.R.styleable.TextInputLayout;

/**
 * Created by andres on 04/10/16.
 */
public class SantaFragment extends Fragment {
        private EditText editTextMensaje;
        private EditText editTextRegalos;
        private TextInputLayout textInputMensaje;
        private InformableDeSanta listenerDeSanta;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listenerDeSanta = (InformableDeSanta)context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.santa_fragment, container, false);

        editTextMensaje = view.findViewById(R.id.editTextMensaje);
        editTextRegalos = view.findViewById(R.id.editTextRegalos);
        textInputMensaje = view.findViewById(R.id.textInputLayoutMensaje);

        FloatingActionButton buttonEnviar = view.findViewById(R.id.floatActionButton);

        buttonEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validarYAvisarMendaje();
            }
        });

        return view;
    }

    private void validarYAvisarMendaje(){
        String mensaje = editTextMensaje.getText().toString();
        String regalos = editTextRegalos.getText().toString();

        if(mensaje.equals("")){
            textInputMensaje.setError("Porfavor Complete el campo mensaje");
            return;
        }
        textInputMensaje.setError(null);
        listenerDeSanta.mensajeYRegalosSeleccionados(mensaje,regalos);
    }

    public interface InformableDeSanta{
        public void mensajeYRegalosSeleccionados(String mensaje, String regalos);
    }
}
