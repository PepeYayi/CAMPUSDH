package com.example.digitalhouse.floatbuttonbase;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class MensajeAceptadoFragment extends Fragment {
    public static final String MENSAJE = "Mensaje";
    public static final String REGALOS = "REGALOS";


    public MensajeAceptadoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_mensaje_aceptado, container, false);

        Bundle unBundle = getArguments();
        String mensaje = unBundle.getString(MENSAJE);
        String regalos = unBundle.getString(REGALOS);

        TextView textViewMensaje = view.findViewById(R.id.textViewMensaje);
        TextView textViewRegalos = view.findViewById(R.id.textViewRegalos);

        if(regalos.length()==0){
            regalos = "No pidio regalos";
        }

        textViewMensaje.setText(mensaje);
        textViewRegalos.setText(regalos);

        return view;
    }

}
