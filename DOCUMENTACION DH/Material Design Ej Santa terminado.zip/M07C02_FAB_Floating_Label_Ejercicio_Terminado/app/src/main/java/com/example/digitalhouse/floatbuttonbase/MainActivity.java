package com.example.digitalhouse.floatbuttonbase;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements SantaFragment.InformableDeSanta{

    private FragmentManager miFragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        miFragmentManager = getFragmentManager();

        SantaFragment santaFragmnt = new SantaFragment();

        FragmentTransaction unaTransaccion = miFragmentManager.beginTransaction();
        unaTransaccion.replace(R.id.contenedorDeFragments, santaFragmnt);
        unaTransaccion.commit();

    }

    @Override
    public void mensajeYRegalosSeleccionados(String mensaje, String regalos) {
        Intent unIntent = new Intent(this,MensajeAceptadoActivity.class);
        Bundle unBundle = new Bundle();

        unBundle.putString(MensajeAceptadoFragment.MENSAJE,mensaje);
        unBundle.putString(MensajeAceptadoFragment.REGALOS,regalos);

        unIntent.putExtras(unBundle);

        startActivity(unIntent);
    }
}
