package Ejercitacion2;

/**
 * Created by andres on 31/03/16.
 */
public class Ejercicio5 {

    public Boolean contieneLetraA(String unTexto){
        //Comenzar a escribir código acá
        return true;
    }

    //No cambiar nada de aca hacia abajo
    public static void main(String[] args){
        Ejercicio5 ejercicio5 = new Ejercicio5();
        //Test 1
        System.out.println(ejercicio5.contieneLetraA("hello world"));
        //Test 2
        System.out.println(ejercicio5.contieneLetraA("zanahoria"));
        //Test 3
        System.out.println(ejercicio5.contieneLetraA("probando mi funcion"));
    }
}

