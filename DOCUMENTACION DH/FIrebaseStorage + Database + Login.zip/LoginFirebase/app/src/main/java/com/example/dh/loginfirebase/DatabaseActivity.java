package com.example.dh.loginfirebase;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import pl.aprilapps.easyphotopicker.DefaultCallback;
import pl.aprilapps.easyphotopicker.EasyImage;

public class DatabaseActivity extends AppCompatActivity {

    private static final String FOTOS_ROOT_STORAGE = "fotosperfil/";
    private ImageView imagenContacto;
    public static final String CONTACTOS = "Contactos";
    // Write a message to the database
    FirebaseDatabase database;


    EditText editTextID;
    EditText editTextNombre;
    EditText editTextApellido;
    EditText editTextTelfono;
    EditText editIdContactoAcargar;

    Button botonCargarUsuario;
    Button botonTraerLista;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);
        // Write a message to the database
        database = FirebaseDatabase.getInstance();
        editIdContactoAcargar = findViewById(R.id.contacto_a_cargar_edit_id);
        imagenContacto = findViewById(R.id.imageView);
        imagenContacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarFoto();
            }
        });
        editTextID = findViewById(R.id.editTextID);
        editTextNombre = findViewById(R.id.editTextNombre);
        editTextApellido = findViewById(R.id.editTextApellido);
        editTextTelfono = findViewById(R.id.editTextTelefono);

        botonCargarUsuario = findViewById(R.id.BotonCargarContacto);
        botonTraerLista = findViewById(R.id.BotonTraerContactos);

        botonCargarUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Contacto contacto = new Contacto(editTextID.getText().toString(), editTextNombre.getText().toString(), editTextApellido.getText().toString(), editTextTelfono.getText().toString());
                contacto.setImagePath(FOTOS_ROOT_STORAGE + contacto.getId());

                subirContactoAlaDatabase(contacto);
                subirFotoAlStorage(contacto);
            }
        });

        botonTraerLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                traerTodosLosContactos();
            }
        });


    }

    private void cargarFoto() {
        EasyImage.openChooserWithGallery(this, "Selecciona imagen", 999);

    }

    private void subirContactoAlaDatabase(Contacto contacto) {
        DatabaseReference reference = database.getReference()
                .child(CONTACTOS)
                .child(contacto.getId());


        reference.setValue(contacto);

    }


    private void traerContactoPorId(String id) {
        DatabaseReference reference = database.getReference().child(CONTACTOS).child(id);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                if (dataSnapshot.exists()) {
                    Contacto contacto = dataSnapshot.getValue(Contacto.class);
                    editTextID.setText(contacto.getId());
                    editTextApellido.setText(contacto.getApellido());
                    editTextNombre.setText(contacto.getNombre());
                    editTextTelfono.setText(contacto.getTelefono());
                    cargarImagenDescargadaDelStorage(contacto.getImagePath());
                } else {
                    Toast.makeText(DatabaseActivity.this, "Id inexistente", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(DatabaseActivity.this, "Fallo", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void clickCargarContactoPorId(View view) {
        traerContactoPorId(editIdContactoAcargar.getText().toString());
    }

    private void cargarImagenDescargadaDelStorage(String imagePath) {
        //opcion 1
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference reference = storage.getReference();
        reference = reference.child(imagePath);

        try {
            final File archivo = File.createTempFile("fotoandroid", "jpg");
            reference.getFile(archivo).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {

                    Picasso.get().load(archivo.getAbsoluteFile()).into(imagenContacto);
                }
            });
        } catch (Exception e) {

        }
        //opcion 2
        /*Glide.with(this  context )
                .using(new FirebaseImageLoader())
                .load(reference)
                .into(imagenContacto);*/
    }

    private void traerTodosLosContactos() {

        DatabaseReference reference = database.getReference().child(CONTACTOS);


        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                List<Contacto> contactosList = new ArrayList<>();


                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Contacto contacto = snapshot.getValue(Contacto.class);
                    contactosList.add(contacto);
                }

                Toast.makeText(DatabaseActivity.this, contactosList.toString(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(DatabaseActivity.this, "Fallo", Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        EasyImage.handleActivityResult(requestCode, resultCode, data, this, new DefaultCallback() {
            @Override
            public void onImagePickerError(Exception e, EasyImage.ImageSource source, int type) {
                //Some error handling
            }

            @Override
            public void onImagesPicked(List<File> imagesFiles, EasyImage.ImageSource source, int type) {
                //Handle the images

                File photo = imagesFiles.get(0);
                Picasso.get().load(photo).into(imagenContacto);
                //si ustedes quieren decodificar el file manualmente
                //Bitmap bitmap = BitmapFactory.decodeFile(photo.getAbsolutePath());
                // imagenContacto.setImageBitmap(bitmap);
            }
        });
    }

    public void subirFotoAlStorage(Contacto contacto) {

        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference reference = storage.getReference();

        StorageReference referencePhoto = reference.child(contacto.getImagePath());

        imagenContacto.setDrawingCacheEnabled(true);
        imagenContacto.buildDrawingCache();
        Bitmap bitmap = imagenContacto.getDrawingCache();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        UploadTask uploadTask = referencePhoto.putBytes(data);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Handle unsuccessful uploads
                Toast.makeText(DatabaseActivity.this, exception.toString(), Toast.LENGTH_LONG).show();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
                Toast.makeText(DatabaseActivity.this, taskSnapshot.toString(), Toast.LENGTH_LONG).show();

            }
        });
    }
}
