import java.util.ArrayList;

public class Cart {

    private ArrayList<Vendible> vendibles;

    public Cart(){
        vendibles = new ArrayList<>();
    }

    public void agregarVendible(Vendible unVendible){
        vendibles.add(unVendible);
    }

    public void eliminarVendible(Vendible unVendible){
        vendibles.remove(unVendible);
    }

    public Double sumaTotal(){

        Double sumaParcial = 0.0;
        for(Integer i = 0; i < vendibles.size(); i++){

            Double precio = vendibles.get(i).informarPrecio();
            sumaParcial = sumaParcial + precio;
        }
        return sumaParcial;
    }
}
