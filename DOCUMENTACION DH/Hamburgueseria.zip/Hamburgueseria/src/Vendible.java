public interface Vendible {

    public Double informarPrecio();

}
