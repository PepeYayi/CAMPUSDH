public class Hamburguesa {
}
