public class Gaseosa extends ProductoIndividual {

    public Gaseosa() {
        super(30.0);
    }
}
