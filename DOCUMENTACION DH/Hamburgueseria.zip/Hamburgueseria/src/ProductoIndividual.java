public class ProductoIndividual implements Vendible {

    private Double precio;

    public ProductoIndividual(Double precio) {
        this.precio = precio;
    }

    @Override
    public Double informarPrecio() {
        return precio;
    }
}

