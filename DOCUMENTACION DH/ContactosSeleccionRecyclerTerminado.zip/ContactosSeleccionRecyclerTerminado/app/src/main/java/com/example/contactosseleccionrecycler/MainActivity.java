package com.example.contactosseleccionrecycler;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements ContactoListadoFragment.NotificadorAgregarContacto,
        AgregarContactoFragment.NotificadorFormularioContacto {

    private static final String AGREGAR_FRAG_TAG = "agregar_frag_tag";
    private static final String LISTADO_FRAG_TAG = "listado_frag_tag";
    private ContactoListadoFragment listadoFragmentContacto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listadoFragmentContacto = new ContactoListadoFragment();
        cargarFragmentListadoContactos();
    }

    private void cargarFragmentListadoContactos() {
        cargarFragment(listadoFragmentContacto, false, LISTADO_FRAG_TAG);
    }

    @Override
    public void clickAgregarContacto() {
        AgregarContactoFragment agregarContactoFragment = new AgregarContactoFragment();
        cargarFragment(agregarContactoFragment, true, AGREGAR_FRAG_TAG);
        //SI NO SE PONE EL BACKGROUND DEL SEGUNDO FRAGMENT EN CLICKEABLE = TRUE, SE PODRIA HACER ACTIVANDO EL METODO DE ABAJO
        //QUE LO QUE HACE ES ESCONDER AL PRIMER FRAGMENT CON EL .Hide()
        //mostrarFragmentAgregarContacto();
    }

    private void mostrarFragmentAgregarContacto() {
        AgregarContactoFragment agregarContactoFragment = new AgregarContactoFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.container, agregarContactoFragment, AGREGAR_FRAG_TAG);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.hide(listadoFragmentContacto);
        //fragmentTransaction.show()
        fragmentTransaction.commit();
    }

    private void cargarFragment(Fragment fragment, boolean addToBackStack, String tag) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.container, fragment, tag);
        if (addToBackStack) {
            fragmentTransaction.addToBackStack(null);
        }
        fragmentTransaction.commit();
    }

    @Override
    public void verDetalleContacto(Contacto contacto) {
        Intent intent = new Intent(this, DetalleActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable(DetalleActivity.CONTACTO_DETALLE, contacto);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void cancelar() {
        super.onBackPressed();
    }

    @Override
    public void agregarContacto(Contacto contacto) {
        listadoFragmentContacto.agregarContacto(contacto);
        super.onBackPressed();
    }

    @Override
    public void onBackPressed() {
        if (fragmentListadoEstaEnPantalla()) {
            if (listadoFragmentContacto.hayElementosSeleccionados()) {
                listadoFragmentContacto.deshacerSeleccionDeContactos();
            } else {
                super.onBackPressed();
            }
        } else super.onBackPressed();
    }

    public boolean fragmentListadoEstaEnPantalla() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment currentFragment = fragmentManager.findFragmentById(R.id.container);
        return (currentFragment != null && currentFragment.getTag().equals(LISTADO_FRAG_TAG));
    }
}