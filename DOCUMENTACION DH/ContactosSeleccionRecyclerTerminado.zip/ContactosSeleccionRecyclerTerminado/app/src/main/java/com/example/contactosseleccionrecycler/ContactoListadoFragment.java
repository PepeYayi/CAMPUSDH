package com.example.contactosseleccionrecycler;


import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class ContactoListadoFragment extends Fragment {

    private RecyclerView recyclerView;
    private ContactoAdapter adapter;
    private FloatingActionButton botonAgregar;
    private NotificadorAgregarContacto notificadorAgregarContacto;
    private List<Contacto> contactosAEliminar;
    private ImageView deleteIcon;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_contacto_listado, container, false);
        recyclerView = v.findViewById(R.id.recycler_id);
        botonAgregar = v.findViewById(R.id.boton_agregar_id);
        deleteIcon = v.findViewById(R.id.delete_button_id);
        deleteIconClick();
        contactosAEliminar = new ArrayList<>();
        clickBotonAgregar();
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        adapter = new ContactoAdapter(getListadoContactos(), new ContactoAdapter.NotificadorClickContacto() {
            @Override
            public void longClickContacto(Contacto contacto) {
                if (contactosAEliminar.contains(contacto)) {
                    contactosAEliminar.remove(contacto);
                } else {
                    contactosAEliminar.add(contacto);
                }

                if (contactosAEliminar.size() > 0) {
                    deleteIcon.setVisibility(View.VISIBLE);
                } else {
                    deleteIcon.setVisibility(View.GONE);
                }
            }

            @Override
            public void clickImagenContacto(Contacto contacto) {
                notificadorAgregarContacto.verDetalleContacto(contacto);
            }
        });
        recyclerView.setAdapter(adapter);
        return v;
    }

    private void deleteIconClick() {
        deleteIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.borrarContactos(contactosAEliminar);
                deleteIcon.setVisibility(View.GONE);
                contactosAEliminar.clear();
            }
        });
    }

    private void clickBotonAgregar() {
        botonAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notificadorAgregarContacto.clickAgregarContacto();
            }
        });
    }

    private List<Contacto> getListadoContactos() {
        List<Contacto> contactos = new ArrayList<>();
        Contacto contactoSuperman = new Contacto("Superman", "Le gusta la criptonita, lucha contra el crimen y le tiene miedo" +
                "a batman", R.drawable.superman);
        Contacto contactoBatman = new Contacto("Batman", "Super inteligente y atento a todos los problemas. Vive en ciudad gotica " +
                "y pelea contra el guason", R.drawable.batman);
        Contacto contactoGoku = new Contacto("Goku", "Su ataque preferido es el kame kame ka"
                , R.drawable.goku);

        contactos.add(contactoSuperman);
        contactos.add(contactoBatman);
        contactos.add(contactoGoku);
        return contactos;
    }

    public boolean hayElementosSeleccionados() {
        return !contactosAEliminar.isEmpty();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        notificadorAgregarContacto = (NotificadorAgregarContacto) context;
    }

    public void agregarContacto(Contacto contacto) {
        adapter.agregarContacto(contacto);
        recyclerView.scrollToPosition(adapter.getItemCount()-1);
    }

    public void deshacerSeleccionDeContactos() {
        deleteIcon.setVisibility(View.GONE);
        for(Contacto contacto : contactosAEliminar){
            contacto.setSeleccionado(false);
        }
        contactosAEliminar.clear();
        adapter.notifyDataSetChanged();
    }

    public interface NotificadorAgregarContacto {
        public void clickAgregarContacto();

        public void verDetalleContacto(Contacto contacto);
    }


}
