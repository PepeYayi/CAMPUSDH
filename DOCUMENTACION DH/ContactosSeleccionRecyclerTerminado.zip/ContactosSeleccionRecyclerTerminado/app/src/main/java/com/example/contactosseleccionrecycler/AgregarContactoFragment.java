package com.example.contactosseleccionrecycler;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class AgregarContactoFragment extends Fragment {

    private static final int NO_HAY_IMAGEN_SELECCIONADO = 0;
    private TextView agregarContacto;
    private TextView cancelar;
    private EditText nombreContactoEdit;
    private EditText descripcionContactoEdit;
    private ImageView imagenContacto;
    private RadioGroup radioGroup;
    private NotificadorFormularioContacto notificadorAgregarContacto;
    private int imageIDSeleccionada;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_agregar_contacto, container, false);
        agregarContacto = view.findViewById(R.id.agregar_contacto_boton_id);
        nombreContactoEdit = view.findViewById(R.id.nombre_contacto_edit_id);
        imagenContacto = view.findViewById(R.id.imagen_agregar_contacto);
        descripcionContactoEdit = view.findViewById(R.id.descripcion_contacto_edit_id);
        cancelar = view.findViewById(R.id.cancelar_contacto_boton_id);
        radioGroup = view.findViewById(R.id.radio_group_id);
        imageIDSeleccionada = NO_HAY_IMAGEN_SELECCIONADO;
        cancelarContactoClick();
        agregarContactoClick();
        radioGroupListener();
        return view;
    }

    private void radioGroupListener() {
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.superman_radio_button_id:
                        imagenContacto.setImageResource(R.drawable.superman);
                        imageIDSeleccionada = R.drawable.superman;
                        break;
                    case R.id.batman_radio_button_id:
                        imagenContacto.setImageResource(R.drawable.batman);
                        imageIDSeleccionada = R.drawable.batman;
                        break;
                    case R.id.goku_radio_button_id:
                        imagenContacto.setImageResource(R.drawable.goku);
                        imageIDSeleccionada = R.drawable.goku;
                        break;
                }
            }
        });
    }

    private void agregarContactoClick() {

        agregarContacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = nombreContactoEdit.getText().toString();
                if (TextUtils.isEmpty(nombre)) {
                    Toast.makeText(AgregarContactoFragment.this.getActivity(),
                            "Debes completar el nombre!", Toast.LENGTH_SHORT).show();
                    return;
                }
                String descripcion = descripcionContactoEdit.getText().toString();
                if (TextUtils.isEmpty(descripcion)) {
                    Toast.makeText(AgregarContactoFragment.this.getActivity(),
                            "Debes completar la descripcion!", Toast.LENGTH_SHORT).show();
                    return;
                }
                int radioButtonIdSeleccionado = radioGroup.getCheckedRadioButtonId();
                if (!hayAlgunaImagenSeleccionada()) {
                    Toast.makeText(AgregarContactoFragment.this.getActivity(),
                            "Debes seleccionar goku o persona o perro!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Contacto contacto = new Contacto(nombre, descripcion, imageIDSeleccionada);
                notificadorAgregarContacto.agregarContacto(contacto);
            }
        });
    }

    private boolean hayAlgunaImagenSeleccionada() {
        return imageIDSeleccionada != NO_HAY_IMAGEN_SELECCIONADO;
    }

    private void cancelarContactoClick() {
        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notificadorAgregarContacto.cancelar();
            }
        });
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        notificadorAgregarContacto = (NotificadorFormularioContacto) context;
    }

    public interface NotificadorFormularioContacto {
        public void cancelar();
        public void agregarContacto(Contacto contacto);
    }

}
