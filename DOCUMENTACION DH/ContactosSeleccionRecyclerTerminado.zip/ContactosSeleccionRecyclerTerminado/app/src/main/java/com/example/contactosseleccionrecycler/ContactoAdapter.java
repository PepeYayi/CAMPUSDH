package com.example.contactosseleccionrecycler;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by ma on 19/04/18.
 */

public class ContactoAdapter extends RecyclerView.Adapter {
    private List<Contacto> contactos;
    private NotificadorClickContacto notificadorLongClickContacto;

    public ContactoAdapter(List<Contacto> contactos, NotificadorClickContacto notificador) {
        this.contactos = contactos;
        notificadorLongClickContacto = notificador;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.celda_contacto_recycler, parent, false);
        ContactoViewHolder viewHolder = new ContactoViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Contacto contacto = contactos.get(position);
        ContactoViewHolder contactoViewHolder = (ContactoViewHolder) holder;
        contactoViewHolder.loadData(contacto);
    }

    @Override
    public int getItemCount() {
        return contactos.size();
    }

    public void agregarContacto(Contacto contacto) {
        contactos.add(contacto);
        notifyDataSetChanged();

    }

    public void borrarContactos(List<Contacto> contactosAEliminar) {
        contactos.removeAll(contactosAEliminar);
        notifyDataSetChanged();
    }


    public class ContactoViewHolder extends RecyclerView.ViewHolder {

        public TextView contactoNombre;
        public TextView contactoDescripcion;
        public ImageView contactoImangen;
        private FrameLayout seleccionadorCelda;

        public ContactoViewHolder(View itemView) {
            super(itemView);
            contactoNombre = itemView.findViewById(R.id.nombre_contacto);
            contactoDescripcion = itemView.findViewById(R.id.description_contacto);
            contactoImangen = itemView.findViewById(R.id.contacto_imagen_id);
            seleccionadorCelda = itemView.findViewById(R.id.seleccion_contacto_id);
            setearLongClickEnCelda();
            setearClickEnImagenContacto();
        }

        private void setearClickEnImagenContacto() {
            contactoImangen.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Contacto contacto = contactos.get(getAdapterPosition());
                    notificadorLongClickContacto.clickImagenContacto(contacto);
                }
            });
        }

        private void setearLongClickEnCelda() {

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    Contacto contacto = contactos.get(getAdapterPosition());
                    if (contacto.isSeleccionado()) {
                        contacto.setSeleccionado(false);
                        seleccionadorCelda.setVisibility(View.GONE);
                    } else {
                        seleccionadorCelda.setVisibility(View.VISIBLE);
                        contacto.setSeleccionado(true);
                    }
                    notificadorLongClickContacto.longClickContacto(contacto);
                    return true;
                }
            });
        }

        public void loadData(Contacto contacto) {
            contactoNombre.setText(contacto.getNombre());
            contactoDescripcion.setText(contacto.getDescripcion());
            contactoImangen.setImageResource(contacto.getImagenID());
            if (contacto.isSeleccionado()) {
                seleccionadorCelda.setVisibility(View.VISIBLE);
            } else {
                seleccionadorCelda.setVisibility(View.GONE);
            }
        }


    }

    public interface NotificadorClickContacto {
        public void longClickContacto(Contacto contacto);

        public void clickImagenContacto(Contacto contacto);
    }
}
