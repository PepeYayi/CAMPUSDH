package com.example.contactosseleccionrecycler;

import java.io.Serializable;

/**
 * Created by ma on 19/04/18.
 */

public class Contacto implements Serializable {

    private String nombre;
    private String descripcion;
    private Integer imagenID;
    private boolean seleccionado;

    public Contacto(String nombre, String descripcion, Integer imagenID) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.imagenID = imagenID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getImagenID() {
        return imagenID;
    }

    public void setImagenID(Integer imagenID) {
        this.imagenID = imagenID;
    }

    public boolean isSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(boolean seleccionado) {
        this.seleccionado = seleccionado;
    }
}
