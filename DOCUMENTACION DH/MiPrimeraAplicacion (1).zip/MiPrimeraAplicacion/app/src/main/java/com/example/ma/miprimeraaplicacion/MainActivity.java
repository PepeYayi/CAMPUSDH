package com.example.ma.miprimeraaplicacion;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button miBoton;
    private TextView miTexto;
    private EditText miEditorTexto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mi_xml_activity_main);

        miBoton = (Button) findViewById(R.id.boton_main_activity);
        miTexto = (TextView) findViewById(R.id.textview_main_activity);
        miEditorTexto = (EditText) findViewById(R.id.edittext_main_activity);

    }


    public void clickDelBoton(View view){
        Toast.makeText(this,"Tu nombre es: " + miEditorTexto.getText().toString(),Toast.LENGTH_SHORT).show();
        miTexto.setText(miEditorTexto.getText().toString());
    }

}
