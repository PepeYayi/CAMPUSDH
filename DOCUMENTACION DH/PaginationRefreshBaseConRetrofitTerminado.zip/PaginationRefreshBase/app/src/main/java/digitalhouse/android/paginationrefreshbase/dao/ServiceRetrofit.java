package digitalhouse.android.paginationrefreshbase.dao;

import digitalhouse.android.paginationrefreshbase.model.PostContainer;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by DH on 3/4/2018.
 */

public interface ServiceRetrofit {

    @GET("posts/paginated")
    Call<PostContainer> getPosts(@Query("offset") Integer offset,
                                 @Query("limit") Integer limit);

}
