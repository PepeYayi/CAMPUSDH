package com.example.digitalhouse.contador;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Integer contador;
    private TextView textViewTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //cuando se crea el activity le damos el valor de 0
        contador = 0;
        textViewTotal = (TextView) findViewById(R.id.textViewTotal);

        //Como convertir de string a numero y de numero a string
        //String numeroEnPantalla = textViewTotal.getText().toString();
        //Integer numero = Integer.parseInt(numeroEnPantalla);
        //numero ++;
        //String stringDeNumero = String.valueOf(numero);

    }

    public void sumar(View view){

        contador++;
        textViewTotal.setText(contador.toString());
    }

    public void restar(View view){
        contador--;
        textViewTotal.setText(contador.toString());
    }


}
