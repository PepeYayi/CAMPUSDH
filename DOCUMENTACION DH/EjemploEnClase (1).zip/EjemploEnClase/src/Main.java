import Animales.Animal;
import Animales.Gato;
import Animales.Perro;
import Animales.Vaca;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Gato gato = new Gato();
        //gato.hacerRuido();

        Perro perro = new Perro();
        //perro.hacerRuido();

       /* Vaca vaca = new Vaca();

        ArrayList<Animal> animales = new ArrayList<>();
        animales.add(gato);
        animales.add(perro);
        animales.add(vaca);

        for(Integer i = 0; i < animales.size(); i++){

            Animal animal = animales.get(i);
            animal.hacerRuido();
        }*/

       perro.comer(1000);



    }
}
