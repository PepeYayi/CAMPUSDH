package Animales;

public class Perro extends Animal {

    private String raza;


    @Override
    public void hacerRuido() {

    }

    @Override
    public void comer(Integer unaEnergia) {
        super.comer(unaEnergia*2);
    }
}
