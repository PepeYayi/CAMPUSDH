package Animales;

public class Vaca extends Animal {

    @Override
    public void hacerRuido() {
        System.out.println("Muuuuuuuu");
    }

    public void pastar(){
        System.out.println("pastando");
    }
}
