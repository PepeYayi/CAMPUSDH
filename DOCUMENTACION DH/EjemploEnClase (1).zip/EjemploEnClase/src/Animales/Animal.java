package Animales;

public abstract class Animal {

    private Integer energia = 0;

    protected void setEnergia(Integer energia) {
        this.energia = energia;
    }

    public Integer getEnergia() {
        return energia;
    }

    public abstract void hacerRuido();

    public void comer(Integer unaEnergia){
        energia = energia + unaEnergia;
        System.out.println("Mi nueva energia es: " + getEnergia());
    }
}
