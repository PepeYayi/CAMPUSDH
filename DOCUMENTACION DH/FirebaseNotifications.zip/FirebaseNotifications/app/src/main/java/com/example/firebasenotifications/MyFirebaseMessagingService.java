package com.example.firebasenotifications;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/**
 * Created by ma on 01/06/18.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final Object CLAVE_NOMBRE = "nombre";
    private static final String TIPO_NOTIFICACION = "tipo";
    private static final String NOTIFICACION_ME_GUSTA = "notif_me_gusta";
    private static final String NOTIFICACION_AMISTAD = "notif_amistad";
    private static final String ID_AMISTAD = "id";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // ...

        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ

        // Check if message contains a data payload.
        String tipoDeNotificacion;
        String mensajeAMostrar = "";
        String nombre = "";
        if (remoteMessage.getData().size() > 0) {
            tipoDeNotificacion = remoteMessage.getData().get(TIPO_NOTIFICACION);
            if (tipoDeNotificacion.equals(NOTIFICACION_ME_GUSTA)) {
                //VOY A TENER QUE OBTENER A PARTIR DE LAS CLAVES DEL TIPO DE NOTIFICACION "ME GUSTA"
                //LOS VALORES A MOSTRAR
            } else if (tipoDeNotificacion.equals(NOTIFICACION_AMISTAD)) {
                String idUsuario = remoteMessage.getData().get(ID_AMISTAD);
                nombre = remoteMessage.getData().get(CLAVE_NOMBRE);
                mensajeAMostrar = idUsuario + " " + nombre;
            }

        }

        String titleNotification = "";
        String contentText = "";
        //Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            titleNotification = remoteMessage.getNotification().getTitle();
            contentText = remoteMessage.getNotification().getBody();
        }


        // Create an explicit intent for an Activity in your app
        Intent intent = new Intent(this, HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        Bundle bundle = new Bundle();
        bundle.putString(HomeActivity.NOMBRE_USUARIO_BUNDLE, nombre);
        intent.putExtras(bundle);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        //esto es para ponerle sonido a la notificacion
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Notification.Builder mBuilder = new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setStyle(new Notification.BigTextStyle()
                        .bigText("texto grande que se muesta cuando se despliega la notificacion"))
                .setContentTitle(titleNotification)
                .setContentText(contentText + " " + mensajeAMostrar)
                .setContentIntent(pendingIntent)
                //.setSound(defaultSoundUri)
                .setAutoCancel(true);
        //.setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // When you issue multiple notifications about the same type of event,
        // it’s best practice for your app to try to update an existing notification
        // with this new information, rather than immediately creating a new notification.
        // If you want to update this notification at a later date, you need to assign it an ID.
        // You can then use this ID whenever you issue a subsequent notification.
        // If the previous notification is still visible, the system will update this existing notification,
        // rather than create a new one. In this example, the notification’s ID is 001//
        mNotificationManager.notify(001, mBuilder.build());


    }


   
}
