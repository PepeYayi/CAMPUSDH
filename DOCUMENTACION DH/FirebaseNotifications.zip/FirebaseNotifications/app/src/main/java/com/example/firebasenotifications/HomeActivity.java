package com.example.firebasenotifications;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    public static final String NOMBRE_USUARIO_BUNDLE = "nombre_usuario_bundle";
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        textView = findViewById(R.id.textview);
        onNewIntent(getIntent());

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Bundle bundle = intent.getExtras();
        String nombreUsuario = bundle.getString(NOMBRE_USUARIO_BUNDLE);
        if(!TextUtils.isEmpty(nombreUsuario)){
            textView.setText(nombreUsuario);
        }
    }
}
